package com.example.trippy.sameeraapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class BillingActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_billing);
    }
}
