package com.example.trippy.sameeraapp;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

public class dashboard extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);


                /* Listner for bottom Nav STARTS */
        BottomNavigationView bottomNavigationView = (BottomNavigationView)
                findViewById(R.id.navigation);
        Menu menu = bottomNavigationView.getMenu();
        menu.findItem(R.id.action_dashboard).setChecked(true);

        bottomNavigationView.setOnNavigationItemSelectedListener(
                new BottomNavigationView.OnNavigationItemSelectedListener() {
                    @Override
                    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                        switch (item.getItemId()) {
                            case R.id.action_home:
                                break;
                            case R.id.action_saved:
                                Intent intent2 = new Intent(dashboard.this,DetailPage.class);
                                startActivity(intent2);
                                overridePendingTransition(0, 0);
                                return true;
                            case R.id.action_activities:

                                break;
                            case R.id.action_dashboard:
                                Intent intent4 = new Intent(dashboard.this,dashboard.class);
                                startActivity(intent4);
                                overridePendingTransition(0, 0);
                                return true;

                        }
                        return false;
                    }
                });
         /* Listner for bottom Nav ENDS */
    }
}
