package com.example.trippy.sameeraapp;

import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.content.Intent;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class DetailPage extends AppCompatActivity {
    private RecyclerView recyclerView;
    private RecyclerView.Adapter mAdapter;
    private RecyclerView.LayoutManager layoutManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_page);
        //Bundle bundle = getIntent().getExtras();

        //Integer itempos = bundle.getInt("MyData");

        /*if(itempos == 0) {
            TextView textView = (TextView) findViewById(R.id.nameText);
            textView.setTextSize(40);
            textView.setText("Cooking Class with Chef");
        }
        else if(itempos == 1){
            TextView textView = (TextView) findViewById(R.id.nameText);
            textView.setTextSize(40);
            textView.setText("Brooklyn History walk");
        }
        else if(itempos == 2){
            TextView textView = (TextView) findViewById(R.id.nameText);
            textView.setTextSize(40);
            textView.setText("TBD");
        }
        else if(itempos == 3){
            TextView textView = (TextView) findViewById(R.id.nameText);
            textView.setTextSize(40);
            textView.setText("TBD");
        }
        else if(itempos == 4){
            TextView textView = (TextView) findViewById(R.id.nameText);
            textView.setTextSize(40);
            textView.setText("TBD");
        }*/

        /*ViewPager mViewPager = (ViewPager) findViewById(R.id.pager);

// This is just an example. You can use whatever collection of images.
        int[] mResources = {
                R.drawable.cooking1,
                R.drawable.cooking2
        };

        custom_adapter mCustomPagerAdapter = new custom_adapter(this, mResources);

        mViewPager.setAdapter(mCustomPagerAdapter);
        */

        /***************** recycle view STARTS ***************************/
        /*recyclerView = (RecyclerView) findViewById(R.id.my_recycler_view);
        // use this setting to
        // improve performance if you know that changes
        // in content do not change the layout size
        // of the RecyclerView
        recyclerView.setHasFixedSize(true);
        // use a linear layout manager
        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        List<String> input = new ArrayList<>();
        for (int i = 0; i < 10; i++) {
            input.add("Test" + i);
        }// define an adapter
        mAdapter = new recycleAdapter(input);
        recyclerView.setAdapter(mAdapter);*/

        /********************* recycle view ENDS  **************************/
        Button button = (Button) findViewById(R.id.bookbutton);

        // Capture button clicks
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View arg0) {

                // Start NewActivity.class
                Intent myIntent = new Intent(DetailPage.this,
                        BillingActivity.class);
                startActivity(myIntent);
            }
        });
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }


}
